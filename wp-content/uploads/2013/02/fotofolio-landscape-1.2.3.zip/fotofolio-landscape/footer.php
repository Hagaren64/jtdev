  <div class="footer">
    <div class="copy"><?php echo nl2br( wpop_get_option( 'copyright' ) ); ?></div>
  </div> <!-- end of footer -->

</div></div> <!-- end of container -->
<?php wp_footer(); ?>
</body>
</html>
